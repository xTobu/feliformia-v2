export default function (to) {
  const user = useSupabaseUser()
  const publicPages = ['/login', '/reset-password', '/confirm']

  if (!user.value && !publicPages.includes(to.path)) {
    return navigateTo('/login')
  }

  if (user.value && to.path === '/login') {
    return navigateTo('/')
  }
}